#include "player.h"		// <string>

Player::Player() {

	runsScored = 0;
	ballsPlayed = 0;
	ballsBowled = 0;
	runsGiven = 0;
	wicketsTaken = 0;
}
